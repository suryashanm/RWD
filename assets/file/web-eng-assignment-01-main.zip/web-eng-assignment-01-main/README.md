# Web Engineering assignment 01 - Responsive Web Design with Bootstrap

Responsive website design using bootstrap - showcasing my understanding of its various components and responsive design principles.  